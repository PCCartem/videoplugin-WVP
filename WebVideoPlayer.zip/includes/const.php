<?php
// dvideo sources
define('SRC_YOUTUBE', 1);
define('SRC_VIMEO', 2);
define('SRC_MP4', 3);